// OnlyCat Command Center - Configuração para Hostinger
window.ENV = {
  VITE_SUPABASE_URL: 'https://upgfoemhrqwvonboduao.supabase.co',
  VITE_SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVwZ2ZvZW1ocnF3dm9uYm9kdWFvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAzMTM3NDYsImV4cCI6MjA2NTg4OTc0Nn0.36oAbqRcoKrxshag9H2zq0LzfMBm0Tu0UE44YYiEttw',
  VITE_APP_NAME: 'OnlyCat Command Center',
  VITE_APP_VERSION: '1.0.0',
  VITE_ADMIN_EMAIL: 'onlycatbrasil@gmail.com'
};
